# ComputationalThinkingWithAlgorithms
 Project for CTA 2022
 
 Benchmark various sorting algorithms on various arrays of size n of 
 i) uniformly distributed psuedorandom numbers
 ii) partially sorted / nearly sorted numbers

 Controller.class contains main() 
 
 The sorting algorithms choosen are:
 1. Insertion sort - a simple comparison based sort
 2. Quick sort - an efficent comparison based sort
 3. Shell sort - an efficent comparison based sort
 4. Radix sort LSD - a non-comparison sort
 5. Timsort - a hybrid sort

![image](https://user-images.githubusercontent.com/81191184/163055106-24385fc9-05f1-4c29-8c35-f4361e7ac940.png)
